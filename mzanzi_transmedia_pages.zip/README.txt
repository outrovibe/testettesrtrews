MZANZI TRANSMEDIA STORY
=========================

Open index.html first.

Pages:
1. index.html              Cover / introduction
2. feed.html               Mzanzi Feed
3. messages.html           Encrypted Messages
4. drive.html              The Drive
5. transmission-1.html     The Missing Signal
6. transmission-2.html     The Drive
7. transmission-3.html     Beneath Mzanzi
8. transmission-4.html     Charles Wallace Online
9. transmission-5.html     What Love Remembers
10. archive.html            Evidence Archive

Every page is a complete, self-contained HTML file with CSS and JavaScript embedded.
